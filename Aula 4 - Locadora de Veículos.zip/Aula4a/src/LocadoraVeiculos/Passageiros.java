package LocadoraVeiculos;

/**
 *
 * @author RenatoSR
 */
public class Passageiros extends Carros {
    
    private String qtd_passageiros;
    private String opcionais;
    private String cor_ext;
    private String cor_int;
    private int qt_dportas;

    public String getQtd_passageiros() {
        return qtd_passageiros;
    }

    public void setQtd_passageiros(String qtd_passageiros) {
        this.qtd_passageiros = qtd_passageiros;
    }

    public String getOpcionais() {
        return opcionais;
    }

    public void setOpcionais(String opcionais) {
        this.opcionais = opcionais;
    }

    public String getCor_ext() {
        return cor_ext;
    }

    public void setCor_ext(String cor_ext) {
        this.cor_ext = cor_ext;
    }

    public String getCor_int() {
        return cor_int;
    }

    public void setCor_int(String cor_int) {
        this.cor_int = cor_int;
    }

    public int getQt_dportas() {
        return qt_dportas;
    }

    public void setQt_dportas(int qt_dportas) {
        this.qt_dportas = qt_dportas;
    }
    
}
