package LocadoraVeiculos;


/**
 *
 * @author RenatoSR
 */
public class Carros {
    
    private String placa;
    private String procedencia;
    private String marca;
    private String modelo;
    private String anomodelo;
    private String anofabric;
    private String chassi;
    private String renavam;
    private int motor;
    private int km;
    private String combustivel;
    private float consumo_medio;

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnomodelo() {
        return anomodelo;
    }

    public void setAnomodelo(String anomodelo) {
        this.anomodelo = anomodelo;
    }

    public String getAnofabric() {
        return anofabric;
    }

    public void setAnofabric(String anofabric) {
        this.anofabric = anofabric;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public int getMotor() {
        return motor;
    }

    public void setMotor(int motor) {
        this.motor = motor;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public float getConsumo_medio() {
        return consumo_medio;
    }

    public void setConsumo_medio(float consumo_medio) {
        this.consumo_medio = consumo_medio;
    }
     
}
